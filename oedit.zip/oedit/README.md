# OEDIT
![](https://oedit.github.io/oedit.ico)
>OEDIT IS A TEXT EDITOR FROM OLDHELPS,RUN ON WINDOWS ONLY

>OEDIT是来自OLD HELPS的文本编辑器,仅运行在Windows上
## Platform
WINXP，7，10,11
## 平台
WINXP，7，10,11
## WEBSITE(Chinese)
[https://oedit.github.io](https://oedit.github.io)
## 网站（中文）
[https://oedit.github.io](https://oedit.github.io)
## Install and run
>Visit[https://oedit.github.io](https://oedit.github.io) ,Download and run(/en/en.exe)

## 安装和运行
>访问[https://oedit.github.io](https://oedit.github.io) ，下载运行二进制文件。